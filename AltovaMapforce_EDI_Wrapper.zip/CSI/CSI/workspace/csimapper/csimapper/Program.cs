﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSIMapper
{
    class Program
    {
        static void Main(string[] args)
        {
            string InputDirectoryPath = args[0];
            string OutputDirectoryPath = args[1];
            string Output997Directory = args[2];
         

            Mapper csimapper = new Mapper();
            csimapper.Map(InputDirectoryPath, OutputDirectoryPath, Output997Directory);
         



        }
    }
}
