﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Mapping;
using System.IO;

namespace CSIMapper
{
    class TraceTargetConsole : Altova.TraceTarget
    {
        public void WriteTrace(string info)
        {
            Console.Out.WriteLine(info);
        }
    }

    public class Mapper
    {
       /// <summary>
       /// 
       /// </summary>
       /// <param name="InputDirectoryPath"></param>
       /// <param name="OutputDirectoryPath"></param>
        public void Map(string InputDirectoryPath, string OutputDirectoryPath , string Output997DirectoryPath)
        {
            TraceTargetConsole ttc = new TraceTargetConsole();
            string WorkspaceDirectory = "";
            string Workspace997Directory = "";

            try
            {
                if (Directory.Exists(InputDirectoryPath))
                {
                    DirectoryInfo diSource = new DirectoryInfo(InputDirectoryPath);


                    DirectoryInfo diOutputSubDirectory = null;
                    DirectoryInfo diOutput997SubDirectory = null;

                    if (!Directory.Exists(Output997DirectoryPath))
                    {
                        diOutput997SubDirectory = Directory.CreateDirectory(Output997DirectoryPath);
                    }
                    else
                    {
                        diOutput997SubDirectory = new DirectoryInfo(Output997DirectoryPath);
                    }

                    foreach (FileInfo fileInfo in diSource.GetFiles())
                    {
                        string InputFileName = fileInfo.Name;
                        string InputFileNameFullPath = fileInfo.FullName;



                       
                        if (!Directory.Exists(OutputDirectoryPath + "\\" + InputFileName))
                        {
                            diOutputSubDirectory = Directory.CreateDirectory(OutputDirectoryPath + "\\" + InputFileName.Substring(0, InputFileName.IndexOf(".")));
                        }

                       


                        WorkspaceDirectory = diOutputSubDirectory.FullName;
                        Workspace997Directory = diOutput997SubDirectory.FullName;


                        MapPOControl(InputFileNameFullPath, WorkspaceDirectory + "//Control.txt");
                        MapPOShipping(InputFileNameFullPath, WorkspaceDirectory + "//Shipping.csv");
                        MapPOBilling(InputFileNameFullPath, WorkspaceDirectory + "//Billing.csv");
                        MapPOHeader(InputFileNameFullPath, WorkspaceDirectory + "//Billing.csv", WorkspaceDirectory + "//Shipping.csv", WorkspaceDirectory + "//POHeader.txt");
                        MapPODetail(InputFileNameFullPath, WorkspaceDirectory + "//PODetail.txt");



                        MappingMapTopo MappingMapToPO_PREPObject = new MappingMapTopo();
                        MappingMapToPO_PREPObject.RegisterTraceTarget(ttc);


                        Altova.IO.Input ControlSource = Altova.IO.StreamInput.createInput(WorkspaceDirectory + "//Control.txt");
                        Altova.IO.Input PODetailSource = Altova.IO.StreamInput.createInput(WorkspaceDirectory + "//PODetail.txt");
                        Altova.IO.Input POHeaderSource = Altova.IO.StreamInput.createInput(WorkspaceDirectory + "//POHeader.txt");
                        Altova.IO.Output PO_PREPTarget = new Altova.IO.FileOutput(WorkspaceDirectory + "//PO_prep.txt");
                        
                        
                        MappingMapToPO_PREPObject.Run(
                        ControlSource,
                        PODetailSource,
                        POHeaderSource,
                        PO_PREPTarget);

                        using (var source = new StreamReader(WorkspaceDirectory + "//PO_prep.txt"))
                        using (var destination = File.AppendText(OutputDirectoryPath + "//PO.txt"))
                        {
                            var sourceData = source.ReadToEnd();
                            destination.Write(sourceData);

                            destination.Close();
                            source.Close();
                        }


                        Map997(InputFileNameFullPath, OutputDirectoryPath + "\\FAControl.txt" ,Workspace997Directory + "//" +
                            InputFileName.Replace("PO", "FA").Replace("po", "fa"), WorkspaceDirectory + "\\preptext.txt");
                        //MapControl(InputFileNameFullPath,OutputDirectoryPath + "\\FAControl.txt", OutputDirectoryPath + "\\FAControl.txt");
                    }

                }


          
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadLine();
            }

            Console.Out.WriteLine("Finished");
         
        }
//        public void MapControl(string InputFileNameFullPath, string InputFileName, string OutputFileName)
//        {
//            TraceTargetConsole ttc = new TraceTargetConsole();
//            MappingMapToText_file MappingMapToText_fileObject = new MappingMapToText_file();
//            MappingMapToText_fileObject.RegisterTraceTarget(ttc);

//            Altova.IO.Input Name850Source = Altova.IO.StreamInput.createInput(InputFileNameFullPath);
//            Altova.IO.Input FAcontrol2Source = Altova.IO.StreamInput.createInput(InputFileName);
//            Altova.IO.Output Text_file5Target = new Altova.IO.FileOutput(OutputFileName);

//            MappingMapToText_fileObject.Run(
//             Name850Source,
//             FAcontrol2Source,
//             Text_file5Target
//);

      
//        }
        public void MapPOControl(string InputFileName , string OutputFileName)
        {
            TraceTargetConsole ttc = new TraceTargetConsole();
            MappingMapToControl MappingMapToControlObject = new MappingMapToControl();
            MappingMapToControlObject.RegisterTraceTarget(ttc);


            Altova.IO.Input Name850Source = Altova.IO.StreamInput.createInput(InputFileName);
            Altova.IO.Output ControlTarget = new Altova.IO.FileOutput(OutputFileName);

            MappingMapToControlObject.Run(
            Name850Source,
            ControlTarget);
        }


        public void MapPOShipping(string InputFileName , string OutputFileName)
        {
            TraceTargetConsole ttc = new TraceTargetConsole();
            MappingMapToShipping MappingMapToShippingObject = new MappingMapToShipping();
            MappingMapToShippingObject.RegisterTraceTarget(ttc);


            Altova.IO.Input Name850Source = Altova.IO.StreamInput.createInput(InputFileName);
            Altova.IO.Output Shipping2Target = new Altova.IO.FileOutput(OutputFileName);

            MappingMapToShippingObject.Run(
            Name850Source,
            Shipping2Target);

        }

        public void MapPOBilling(string InputFileName , string OutputFileName)
        {

            TraceTargetConsole ttc = new TraceTargetConsole();
            MappingMapToBilling MappingMapToBillingObject = new MappingMapToBilling();
            MappingMapToBillingObject.RegisterTraceTarget(ttc);

            Altova.IO.Input Name850Source = Altova.IO.StreamInput.createInput(InputFileName);
            Altova.IO.Output Billing2Target = new Altova.IO.FileOutput(OutputFileName);

            MappingMapToBillingObject.Run(
            Name850Source,
            Billing2Target);
        }

        public void MapPOHeader(string InputFileName , string InputBillingFileName, string InputShippingFileName , string OutputFileName)
        {


            TraceTargetConsole ttc = new TraceTargetConsole();
            MappingMapToPOHeader MappingMapToPOHeaderObject = new MappingMapToPOHeader();
            MappingMapToPOHeaderObject.RegisterTraceTarget(ttc);

            Altova.IO.Input Name850Source = Altova.IO.StreamInput.createInput(InputFileName);
            Altova.IO.Input Billing2Source = Altova.IO.StreamInput.createInput(InputBillingFileName);
            Altova.IO.Input Shipping2Source = Altova.IO.StreamInput.createInput(InputShippingFileName);
            Altova.IO.Output POHeaderTarget = new Altova.IO.FileOutput(OutputFileName);

            MappingMapToPOHeaderObject.Run(
            Name850Source,
            Billing2Source,
            Shipping2Source,
            POHeaderTarget);


        }

        public void MapPODetail(string InputFileName , string OutputFileName)
        {
            TraceTargetConsole ttc = new TraceTargetConsole();
            MappingMapToPODetail MappingMapToPODetailObject = new MappingMapToPODetail();
            MappingMapToPODetailObject.RegisterTraceTarget(ttc);



            Altova.IO.Input Name850Source = Altova.IO.StreamInput.createInput(InputFileName);
            Altova.IO.Output PODetailTarget = new Altova.IO.FileOutput(OutputFileName);

            MappingMapToPODetailObject.Run(
            Name850Source,
            PODetailTarget);


        }



        public void Map997(string InputFileName, string InputControlFileName, string OutputFileName, string preptextfile)
        {
            TraceTargetConsole ttc = new TraceTargetConsole();
            ttc.WriteTrace("997 start");
           

            ttc.WriteTrace("map to txt");
            {
                MappingMapTopreptext MappingMapTopreptextObject = new MappingMapTopreptext();
                MappingMapTopreptextObject.RegisterTraceTarget(ttc);
            
                Altova.IO.Input FAControlSource = Altova.IO.StreamInput.createInput(InputControlFileName);
                Altova.IO.Output Text_file7Target = new Altova.IO.FileOutput(preptextfile);
                Altova.IO.Input Name850Source = Altova.IO.StreamInput.createInput(InputFileName);

                MappingMapTopreptextObject.Run(
                            Name850Source,
                            FAControlSource,
                            Text_file7Target);
            }
            ttc.WriteTrace("update fa control");
            {
                MappingMapTofacontrol MappingMapTofacontrolObject = new MappingMapTofacontrol();
                MappingMapTofacontrolObject.RegisterTraceTarget(ttc);
                Altova.IO.Input Text_file7Source = Altova.IO.StreamInput.createInput(preptextfile);
                Altova.IO.Output Text_file5Target = new Altova.IO.FileOutput(InputControlFileName);
            
                    MappingMapTofacontrolObject.Run(
                    Text_file7Source,
                    Text_file5Target);
            }
            ttc.WriteTrace("map to 997");
            {
                MappingMapTo997 MappingMapTo997Object = new MappingMapTo997();
                MappingMapTo997Object.RegisterTraceTarget(ttc);
                Altova.IO.Input Text_file8Source = Altova.IO.StreamInput.createInput(preptextfile);
                Altova.IO.Input Name850Source2 = Altova.IO.StreamInput.createInput(InputFileName);
                Altova.IO.Output Name997Target = new Altova.IO.FileOutput(OutputFileName);
                
                    MappingMapTo997Object.Run(
                            Name850Source2,
                            Text_file8Source,
                            Name997Target);
            }
            

        }
    }
}
