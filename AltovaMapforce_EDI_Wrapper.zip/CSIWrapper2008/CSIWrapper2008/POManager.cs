﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace CSIMapper
{
    public class POManager
    {

        public void Append(string DirectoryName, string MasterFileName)
        {

        }

        public void Append(string[] FileName , string MasterFileName)
        {


        }

    }
}
